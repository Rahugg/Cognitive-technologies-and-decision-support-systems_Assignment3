"""Cognitive emotion recognition prototype."""
